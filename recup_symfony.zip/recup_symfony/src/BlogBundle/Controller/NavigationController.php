<?php

namespace BlogBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

class NavigationController extends Controller
{
	public function categoriesNavAction(){
		$categories = $this->getDoctrine()->getRepository('BlogBundle:Categorie')->findAll();

		return $this->render('BlogBundle:Navigation:navCat.html.twig',
			[ 'categories' => $categories ]);
	}
}
?>