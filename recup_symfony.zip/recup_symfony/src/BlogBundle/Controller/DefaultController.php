<?php

namespace BlogBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use BlogBundle\Entity\Commentaire;
use Cocur\Slugify\Slugify;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;


class DefaultController extends Controller
{


	/**
	* @Route("/commentaires/new")
	*/
	public function commentaireAction(Request $post){
		$idArticle = $post->get('id_article');
		$auteur = $post->get('authorComm');
		$contenu = $post->get('comment');

		$article = $this->getDoctrine()->getRepository('BlogBundle:Article')->find($idArticle);

		$commentaire = new Commentaire();

		$commentaire->setAuthor($auteur);
		$commentaire->setContent($contenu);
		$commentaire->setArticle($article);
		$commentaire->setDateCreated(new \DateTime());

		$em = $this->getDoctrine()->getManager();

		$em->persist($commentaire);
		$em->flush();

		return $this->redirect('/'.$article->getCategorie()->getSlug().'/'.$article->getSlug());
	}

	/**
	* @Route("/creationCategorie")
	*/
	public function creationCategorieAction(){

	}

	/**
	* @Route("/modificationCategorie/{categorieSlug}")
	*/
	public function modificationCategorieAction(){

	}

	/**
	* @Route("/supprimerCategorie/{categorieSlug}")
	*/
	public function supprimerCategorieAction(){

	}

	/**
	* @Route("/recherche")
	*/
	public function searchAction(Request $request){
    	$articleRepository = $this->getDoctrine()->getRepository('BlogBundle:Article');
		$resultat = $articleRepository->findBy(['or' => ['title' => $request, 'content' => $request]]);

		return $this->render('BlogBundle:Default:recherche.html.twig',
			[ "resultat" => $resultat ]);
	}

	/**
	* @Route("/categories")
	*/
	public function categoriesAction(){
    	$categorieRepository = $this->getDoctrine()->getRepository('BlogBundle:Categorie');
		$categories = $categorieRepository->findAll();
		return $this->render('BlogBundle:Default:categories.html.twig',
			[ "categories" => $categories ]);
	}

	/**
	* @Route("/{categorieSlug}")
	*/
	public function categoryAction($categorieSlug){
    	$categorieRepository = $this->getDoctrine()->getRepository('BlogBundle:Categorie');
		$categorie = $categorieRepository->findOneBySlug($categorieSlug);

		return $this->render('BlogBundle:Default:categorie.html.twig',
			[
				"categorie" => $categorie
			]);
	}

	/**
	* @Route("/{categorieSlug}/{articleSlug}")
	*/
	public function showAction($categorieSlug, $articleSlug, Request $request){
    	$articleRepository = $this->getDoctrine()->getRepository('BlogBundle:Article');
		$article = $articleRepository->findOneBySlug($articleSlug);

		$commentaire = new Commentaire();
		$commentaire->setArticle($article);

		$form = $this->createFormBuilder($commentaire)
            ->add('author', TextType::class)
            ->add('content', TextareaType::class)
            ->add('save', SubmitType::class)
            ->getForm();

            $form->handleRequest($request);
		
        if ($form->isSubmitted() && $form->isValid()) {
        	$commentaire = $form->getData();
        	$commentaire->setDateCreated(new \DateTime());

			$manager = $this->getDoctrine()->getManager();

			$manager->persist($commentaire);
			$manager->flush();

        	return $this->redirect('/'.$categorieSlug.'/'.$articleSlug);
        }

		return $this->render('BlogBundle:Default:show.html.twig',
			[
				"article" => $article,
				"commentForm" => $form->createView()
			]);

	}

    /**
     * @Route("/")
     */
    public function indexAction()
    {
    	// $slugify = new Slugify();
    	// $test = $slugify->slugify('Bonjour les copains !');
    	// var_dump($test);

    	$categorieRepository = $this->getDoctrine()->getRepository('BlogBundle:Categorie');
    	$categories = $categorieRepository->findAll();

    	$commentaireRepository = $this->getDoctrine()->getRepository('BlogBundle:Commentaire');
    	$commentaires = $commentaireRepository->findBy([], [ 'dateCreated' => 'DESC' ], 5);

    	//var_dump($articles);

        return $this->render('BlogBundle:Default:index.html.twig',
        	[
        		"categories" => $categories,
        		"commentaires" => $commentaires
        	]);
    }

}
