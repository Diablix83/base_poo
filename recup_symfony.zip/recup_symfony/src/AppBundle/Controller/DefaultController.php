<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;


class DefaultController extends Controller
{

    /**
    * @Route("/test")
    */
    public function testAction(){
        return new Response('Hello World!');
    }

    /**
    * @Route("/test/{prenom}-{age}")
    */
    public function multipleActions($prenom, $age){
        $tartuf = [
            "Seat",
            "Smart",
            "BMW"
        ];

        $crayon = new Crayon('Rouge', 'DOOM');

        return $this->render('default/test.html.twig', [
                "prenom" => $prenom,
                "age" => $age,
                "voitures" => $tartuf,
                "crayon" => $crayon
            ]);
    }

    /**
    * @Route("/test/{prenom}")
    */
    public function autreAction($prenom){
        return new Response('Hello '.$prenom.' World!');
    }


    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }
}


class Crayon{
    public $couleur;
    private $marque;


    public function __construct($couleur, $marque){
        $this->couleur = $couleur;
        $this->marque = $marque;
    }

    public function getMarque(){
        return $this->marque;
    }
}
